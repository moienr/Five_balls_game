﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour {

	public int Level = 1;
	public int Points = 0;
	level2BackGround level2BackGround;
	ShrinkToDestroy shrinkToDestroy;
	level2ItemSpawn level2Spwan;
	SpawnManager spawnManager;
	lvl3Spawner lvl3Spawner;
	currentLevelGoingDown currentLevelGoingDown;
    public bool twoFinger= false;

	public UnityEngine.Events.UnityEvent Level3EndEvent;

	
    // Use this for initialization
    void Start () {
		
		



	
		level2BackGround = GameObject.Find("BackGround").GetComponent<level2BackGround>();
		shrinkToDestroy = this.GetComponent<ShrinkToDestroy>();
		level2Spwan = GameObject.Find("SpawnManager").GetComponent<level2ItemSpawn>();
		lvl3Spawner = GameObject.Find("SpawnManager").GetComponent<lvl3Spawner>();
		spawnManager = GameObject.Find("SpawnManager").GetComponent<SpawnManager>();
		currentLevelGoingDown = GameObject.Find("BackGround").GetComponent<currentLevelGoingDown>();
	}
	
	// Update is called once per frame
	void Update () {
		if (Points == 4 && Level ==1)
		{
			shrinkToDestroy.level1To2();
			Level = 2;
			level2BackGround.StartRoutine();
			level2Spwan.lvl2Spwan();
			spawnManager.startPlane();
			twoFinger =true;


			
		}
		if (Points == 8 && Level ==2)
		{
			Level = 3;
			lvl3Spawner.StartLevel3();
			currentLevelGoingDown.goDownBitch();
		}

		if(Points == 12 && Level==3)
		{
			Level =4;
			Level3EndEvent.Invoke();
	


		}
	}
}
