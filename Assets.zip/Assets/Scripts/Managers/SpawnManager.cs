﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour {

    [SerializeField]
    private GameObject planePrefab;
   
    private bool deployed =true;





   

	



 	
	// Update is called once per frame


    IEnumerator planeSpawnRoutine()
    {
		// true = not gameover
        while (deployed)
        {
            yield return new WaitForSeconds(15);
            Instantiate(planePrefab, new Vector3(3.8f, Random.Range(2.7f, 4.55f), 0), Quaternion.identity);
            deployed =false;

        }

    }

    public void startPlane()
    {
        StartCoroutine(planeSpawnRoutine());
    }
 

}
