﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class floorSpawner : MonoBehaviour {


	public GameObject[] ballsArray;
	public GameObject[] ballClone ;
	[SerializeField]
	public SpriteRenderer[] spriteRenderers;
	[SerializeField]
    private bool firstTouch=true;
    private float x;
    private float y;
    private float z;
    private Vector3 spawnPos;
    private bool coFirstTouch;

	[SerializeField]
	private Color[] ballColors;
	

    // Use this for initialization
    void Start () {
	///////////////////////////////////////////////	
   /// colors have been defined in uinty itself///
  ///////////////////////////////////////////////
  
		
		
	}
	
	// Update is called once per frame



	private void OnCollisionEnter2D(Collision2D other) {
		
		if (firstTouch && other.transform.tag =="Player")
		{
			coFirstTouch =true;
 			
			 x =other.transform.position.x;
			 y =other.transform.position.y;
			 z =other.transform.position.z;

			StartCoroutine(loadBallRoutine());
			firstTouch =false;
		}
	}

		IEnumerator loadBallRoutine () 
	{
		while(coFirstTouch)
		{
				for(int i=0 ;i<=3 ;i++)
			{
				float  randomSpawn= ((Random.value) -0.2f)  ;
				 Debug.Log("random num" + randomSpawn);
				spawnPos =new Vector3(x + randomSpawn ,y + 0.01f,z);
				

				ballClone[i]=Instantiate(ballsArray[i] , spawnPos , Quaternion.identity );

				// giving each clone ball a deferent name so each could be draged speretly ya ,Mo is a geneius
				ballClone[i].name = "whiteBall" + i;
				spriteRenderers[i] = ballClone[i].GetComponent<SpriteRenderer>();
				spriteRenderers[i].color =ballColors[i];
				

				yield return new WaitForSeconds(0.1f);
			}
			
			coFirstTouch =false;
			
		}
	}


	public void loadMoreBalls()
	{
		coFirstTouch =true;
		StartCoroutine(loadBallRoutine());
		

	}



}
