﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LineCreator : MonoBehaviour {
    private float x;
    
	[SerializeField]
    private float xSpeed;
	
	TrailRenderer trail;
	public bool color = true;

	private void Start() {
		trail = GetComponent<TrailRenderer>();
	}

    // Update is called once per frame
    void Update () {
		if(transform.position.x < 50)
		{
			x = transform.position.x + xSpeed;
		
		transform.position = new Vector3(x , 0  , 0);
		}

//	trail.startColor = Color.white;
//	trail.endColor= Color.white;
		
	}
}
