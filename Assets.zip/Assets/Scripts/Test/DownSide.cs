﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DownSide : MonoBehaviour {


	// Use this for initialization
	void Start () {
		
	}
	

	
	private void OnTriggerExit2D(Collider2D other) {
		
	
		
			
	}
	
	
}
