﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FingerCatch : MonoBehaviour {
    private Touch touch;
    private Vector3 FingerPos;
	private List<string> names;
	private List<float> distances;
	private List<GameObject> objects;
	[SerializeField]
	private Vector3 freePos;
    private GameObject closestObject;
	WhiteBallDragAndThrow whiteBallDragAndThrow;
	ColorBallDragAndThrow1 colorBallDragAndThrow1;

    // Use this for initialization
    void Start () {
		names = new List<string>();
		distances = new List<float>();
		objects = new List<GameObject>();
		whiteBallDragAndThrow = GameObject.Find("WhiteBall").GetComponent<WhiteBallDragAndThrow>();
		colorBallDragAndThrow1 = GameObject.Find("ColorBall1").GetComponent<ColorBallDragAndThrow1>();
	}
	
	// Update is called once per frame
	void FixedUpdate () {

		if(Input.touchCount >0 && Input.GetTouch(0).phase == TouchPhase.Began)
		{
		RaycastHit2D hit = Physics2D.Raycast(new Vector2(Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).x,Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).y) ,
		Vector2.zero ,
		Mathf.Infinity);

			if (hit.collider !=null ) 
			{
				if(hit.transform.name == "WhiteBall")
				{
					whiteBallDragAndThrow.ballGrabed = true;
					whiteBallDragAndThrow.dragAndThrow();
				}
				if(hit.transform.name == "ColorBall1")
				{
					colorBallDragAndThrow1.ballGrabed = true;
					colorBallDragAndThrow1.dragAndThrow();
				}

			}

			else
			{
				if(Input.touchCount>0 && Input.GetTouch(0).phase == TouchPhase.Began)
				{
					touch = Input.GetTouch(0);
					float x = Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).x;
					float y = Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).y;
					FingerPos = new Vector3 (x,y,0);
					transform.position = FingerPos;
				}
		
			}
		

		}
		if(Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Ended)
		{
			transform.position = freePos;
					
			distances.Clear();
			objects.Clear();
		}
		if(Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Moved)
		{
			transform.position = freePos;
					
			distances.Clear();
			objects.Clear();
		}




	


	}

	private void OnTriggerEnter2D(Collider2D other) {
		if(other.tag == "Ball" || other.tag=="ColorBall" || other.tag == "Movable" )
		{
			
			
			distances.Add(Vector3.Distance(transform.position , other.transform.position));
			objects.Add(other.gameObject);

			
			if(objects.Count>1)
			{
				for (int i=1  ;  i<distances.Count ;i ++)
				{
					Debug.Log("distance  " + i +"  is:  " +distances[i]);
					if(distances[i] > distances[i-1])
					{
						closestObject = objects[i];
					}else{
						closestObject = objects[i-1];

					}
				}
			}else if(objects.Count ==1)
			{
				closestObject = objects[0];
			}
			

			

			if (closestObject.transform.name == "WhiteBall")
			{
				whiteBallDragAndThrow.ballGrabed = true;
				whiteBallDragAndThrow.dragAndThrow();
				
			}
			if(closestObject.transform.name == "ColorBall1")
			{
					colorBallDragAndThrow1.ballGrabed = true;
					colorBallDragAndThrow1.dragAndThrow();
			}

		}
	
	

	}
}
