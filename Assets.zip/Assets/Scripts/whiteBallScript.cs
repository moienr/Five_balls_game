﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class whiteBallScript : MonoBehaviour {
    private float touchStartTime;
    private Vector2 stratPos;
    private bool ballGrabed;
    private Touch touch;
    private string objectName;
    private bool isSpawning =false;
	private Rigidbody2D rb;
    private Vector3 newPos;
	private dotLineDetector dotLine;
	[SerializeField]
    public bool ballIsUnder;
	SpringJoint2D joint2D;

    // Use this for initialization
    void Start () {
		objectName = transform.name;
		rb = GetComponent<Rigidbody2D>();
		dotLine = GameObject.Find("dotLine").GetComponent<dotLineDetector>();

		joint2D = GetComponent<SpringJoint2D>();
		Destroy(joint2D ,4f);

	}
	// Update is called once per frame
	void FixedUpdate () {
		if (dotLine.canPass || ballIsUnder)
		{
			dragAndThrow();	
		}


			
	}
	private void dragAndThrow() {
		
	if(Input.touchCount >0 && Input.GetTouch(0).phase == TouchPhase.Began)
	{
		RaycastHit2D hit = Physics2D.Raycast(new Vector2(Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).x,
		Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).y) ,Vector2.zero , 0f);
		if (hit.collider !=null && hit.transform.tag == "Player")
		{
		ballGrabed = true;
		}
	}
		// keeping the ball under finger a frame after touch began
		if(ballGrabed &&Input.touchCount>0)
		{
		touch = Input.GetTouch(0);
		float x = Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).x;
		float y = Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).y;
		newPos = new Vector3 (x,y,0);
		rb.velocity = (newPos - transform.position) *10;
		
			if(transform.position.y > 0)
			{
				ballGrabed = false;
			}


			
		}
		
		if(Input.touchCount >0 && (Input.GetTouch(0).phase == TouchPhase.Ended || Input.GetTouch(0).phase == TouchPhase.Canceled))
		{
			ballGrabed = false;
		}
	}
}
