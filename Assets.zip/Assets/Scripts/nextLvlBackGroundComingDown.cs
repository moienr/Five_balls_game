﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class nextLvlBackGroundComingDown : MonoBehaviour {

	private void Start() {
		StartCoroutine(goingDown());
	}

	// Use this for initialization
	IEnumerator goingDown() 
	{
		while (transform.position.y > 0)
		{
			transform.position = Vector3.Lerp(transform.position , new Vector3(0,-0.05f,0), Time.deltaTime);
			yield return null;
		}

	
		

	
	}


}
