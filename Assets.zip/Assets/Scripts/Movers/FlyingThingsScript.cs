﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlyingThingsScript : MonoBehaviour {
	Rigidbody2D rb ;
    private bool mayDay =false;

    // Use this for initialization
    void Start () {
		
		rb = GetComponent<Rigidbody2D>();
		Destroy (this.gameObject , 10f);
	}
	
	// Update is called once per frame
	void Update () {
		if (!mayDay)
		{
			rb.velocity = Vector3.left  ;
		}else
		{
			rb.AddForce(Vector3.down / 10) ;
		}
		
		
	}

	private void OnCollisionEnter2D(Collision2D other) {
			mayDay =true;
			rb.gravityScale =0.1f;

		}
}
