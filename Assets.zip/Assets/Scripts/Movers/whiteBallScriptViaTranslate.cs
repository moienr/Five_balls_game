﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class whiteBallScriptViaTranslate : MonoBehaviour {

    private float touchStartTime;
    private Vector2 stratPos;
    private bool ballGrabed;
    private float touchFinishTime;
    private float timePassed;
    private Vector2 endPos;
    private Vector2 direction;
    private Vector2 force;
    private Touch touch;
    private float tempTime;
	Ray ray;
	RaycastHit hit;
	private bool firstTouh;
    private string objectName;
    private bool firstTimeUnderHappend =false;
    private bool isSpawning =false;




    // Use this for initialization
    void Start () {
		objectName = transform.name;
	
		
	}
	
	// Update is called once per frame
	void Update () {
		

			
		
		
		dragAndThrow();		
		


	}



	public void throwing()
	{
		// getting first position
		if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
		{

			touchStartTime = Time.time;
			stratPos = Input.GetTouch(0).position;

			
			//<TODO> jashun ro dorost kon bayad tuye raycast bashan  <DONE>\\
			GetComponent<Rigidbody2D>().isKinematic= true;
			GetComponent<Rigidbody2D>().velocity = new Vector2(0,0);
			this.GetComponent<Rigidbody2D>().gravityScale =0;

		}


		// getting second postion and then throw the ball
		if (Input.touchCount > 0 && (Input.GetTouch(0).phase == TouchPhase.Ended ||Input.GetTouch(0).phase == TouchPhase.Canceled))
		{
			touchFinishTime = Time.time;
			timePassed = touchFinishTime - touchStartTime ;
			endPos = Input.GetTouch(0).position;

			

			direction = endPos - stratPos;
			force  = direction/tempTime;

			GetComponent<Rigidbody2D>().isKinematic= false;
			GetComponent<Rigidbody2D>().AddForce(force /3);
			this.GetComponent<Rigidbody2D>().gravityScale =1;
			 

			Debug.Log("direction : " + direction);
			Debug.Log("force :" + force);
			
			

		

		}
       //<summary> if time passed is more than half sec its gonna rewrite pos and time so its a straight way for throwing 
		if (touchStartTime>0 && Input.touchCount >0 ) 
		{
			tempTime = Time.time - touchStartTime;
			if(tempTime>0.5f)
		{
				touchStartTime = Time.time;
				stratPos = Input.GetTouch(0).position;
		}
		}
	}
	private void dragAndThrow() {	
	if(Input.touchCount >0)
	{
		RaycastHit2D hit = Physics2D.Raycast(new Vector2(Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).x,Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).y) ,Vector2.zero , 0f);
		if (hit.collider !=null && hit.transform.name == objectName)
		{
		ballGrabed = true;
		touch = Input.GetTouch(0);
		float x = -3.115f + 6.23f * touch.position.x / Screen.width;
		float y = -5.015f + 10.03f * touch.position.y / Screen.height;
		hit.transform.position = new Vector3 (x,y,0);
		throwing();
		}
	}
		// keeping the ball under finger a frame after touch began
		if(ballGrabed)
		{
		touch = Input.GetTouch(0);
		float x = -3.115f + 6.23f * touch.position.x / Screen.width;
		float y = -5.015f + 10.03f * touch.position.y / Screen.height;
		transform.position = new Vector3 (x,y,0);
		}
		if(Input.touchCount >0 && (Input.GetTouch(0).phase == TouchPhase.Ended || Input.GetTouch(0).phase == TouchPhase.Canceled))
		{
			ballGrabed = false;
		}
	}
}
