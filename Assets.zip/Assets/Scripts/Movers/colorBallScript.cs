﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class colorBallScript : MonoBehaviour {
    private float touchStartTime;
    private Vector2 stratPos;
    private bool ballGrabed;
    private Touch touch;
    private string objectName;
    private bool isSpawning =false;
	private Rigidbody2D rb;
    private Vector3 newPos;
    private Vector3 newPosNoWhite;

    // Use this for initialization
    uperSideScript uperSide;
	downSideScript downSide;
    private bool ballGrabed1;
	GameManager gameManager;

    void Start () {
		objectName = transform.name;
		rb = GetComponent<Rigidbody2D>();
		uperSide = GameObject.Find("uperSide").GetComponent<uperSideScript>();
		downSide = GameObject.Find("downSide").GetComponent<downSideScript>();
		gameManager = GameObject.Find("GameManager").GetComponent<GameManager>();
	}
	// Update is called once per frame
	void FixedUpdate () {

		finger0Drag();
		
		

	
	}

	private void finger0Drag()
	{
			if(Input.touchCount>0)
		{
		touch = Input.GetTouch(0);
		float x = Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).x;
		float y = Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).y;
		newPos = new Vector3 (x,y,0);
		newPosNoWhite = new Vector3 (x,-0.431f,0);
		}
		
		if (Input.touchCount ==0 && transform.position.y > 0 )	
		{
			rb.velocity =Vector3.down *5;
		}	

		if (uperSide.whiteBallIsIn)
		{
			dragAndThrow0();
		}else if (transform.position.y <-0.43f && newPos.y <-0.43f)
		{
			dragAndThrow0();
	
			
		}else 
		{
			if(transform.position.y >-0.43f)
			{
				rb.velocity = Vector3.down *5 ;
			
				
			}
		}
	}









	private void dragAndThrow0() {
		
	if(Input.touchCount >0 && Input.GetTouch(0).phase == TouchPhase.Began)
	{
		RaycastHit2D hit = Physics2D.Raycast(new Vector2(Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).x,Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).y) ,Vector2.zero , 0f);
		if (hit.collider !=null && hit.transform.name == objectName)
		{
		
		ballGrabed = true;

		}
	}
		// keeping the ball under finger a frame after touch began
		if(ballGrabed &&Input.touchCount>0)
		{
	
		rb.velocity = (newPos - transform.position) *10;
		}
		
		if(Input.touchCount >0 && (Input.GetTouch(0).phase == TouchPhase.Ended || Input.GetTouch(0).phase == TouchPhase.Canceled))
		{
			ballGrabed = false;
		}
	
	}










}
