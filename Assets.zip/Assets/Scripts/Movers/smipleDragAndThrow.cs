﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class smipleDragAndThrow : MonoBehaviour {
 private float touchStartTime;
    private Vector2 stratPos;
    public bool ballGrabed;
    private Touch touch;
    private string objectName;
    private bool isSpawning =false;
	private Rigidbody2D rb;
    private Vector3 newPos;
    // Use this for initialization
	uperSideScript uperSide;
	downSideScript downSide;
	[SerializeField]
    private float movingSpeed =10;

    void Start () {
		objectName = transform.name;
		rb = GetComponent<Rigidbody2D>();
	
	}
	// Update is called once per frame
	void FixedUpdate () {

		if(Input.touchCount>0)
		{
		touch = Input.GetTouch(0);
		float x = Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).x;
		float y = Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).y;
		newPos = new Vector3 (x,y,0);
		}
		
		dragAndThrow();

	
	}
	private void dragAndThrow() {
		
	if(Input.touchCount >0 && Input.GetTouch(0).phase == TouchPhase.Began)
	{
		RaycastHit2D hit = Physics2D.Raycast(new Vector2(Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).x,Camera.main.ScreenToWorldPoint(Input.GetTouch(0).position).y) ,Vector2.zero , 0f);
		if (hit.collider !=null && hit.transform.name == objectName)
		{
		
		ballGrabed = true;

		}
	}
		// keeping the ball under finger a frame after touch began
		if(ballGrabed &&Input.touchCount>0)
		{
	
		rb.velocity = (newPos - transform.position) *movingSpeed;
		}
		
		if(Input.touchCount >0 && (Input.GetTouch(0).phase == TouchPhase.Ended || Input.GetTouch(0).phase == TouchPhase.Canceled))
		{
			ballGrabed = false;
		}
	
	}
}
