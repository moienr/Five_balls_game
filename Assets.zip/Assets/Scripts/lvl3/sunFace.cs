﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sunFace : MonoBehaviour {
	[SerializeField]
	GameObject notGrabbed;
	[SerializeField]
	GameObject Grabbed;
	smipleDragAndThrow smipleDrag;

	// Use this for initialization
	void Start () {
		smipleDrag = this.GetComponent<smipleDragAndThrow>();
	}
	
	// Update is called once per frame
	void Update () {
		if (!smipleDrag.ballGrabed)
		{
			notGrabbed.SetActive(true);
			Grabbed.SetActive(false);
		}else
		{
			notGrabbed.SetActive(false);
			Grabbed.SetActive(true);
		}
	}
}
