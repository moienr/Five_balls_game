﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lvl3Spawner : MonoBehaviour {
    private bool mrBool=true;
	[SerializeField]
	GameObject lvl3BackGround ;

	private void Start() 
	{
		
	}

    IEnumerator spawner()
{
	while(mrBool)
	{
	Instantiate(lvl3BackGround , new Vector3 (0,10.32f ,0) , Quaternion.identity);
	mrBool = false;
	yield return null;
	}
}


	public void StartLevel3()
	{
		StartCoroutine(spawner());
	}
}
