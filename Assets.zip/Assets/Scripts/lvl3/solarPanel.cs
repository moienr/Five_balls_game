﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class solarPanel : MonoBehaviour {

	doorScript doorScript;

	// Use this for initialization
	void Start () {
		doorScript = GameObject.Find("door").GetComponent<doorScript>();
	}
	
	private void OnTriggerEnter2D(Collider2D other) {
		if (other.name == "sun")
		{
			doorScript.openCall();
		}


	
	}

	private void OnTriggerExit2D(Collider2D other) {
		if (other.name == "sun")
		{
			doorScript.closeCall();
		}
	}
}
