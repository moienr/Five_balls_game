﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class planeMoving : MonoBehaviour {

	[SerializeField]
	private float xSpeed;
	[SerializeField]
	private float ySpeed;

	private void Start() {
	
		Destroy(this.gameObject , 5f);
	}


	
	// Update is called once per frame
	
	private void Update() {
		transform.position =new Vector3(transform.position.x + xSpeed  , transform.position.y + ySpeed ,0);
	}


	
		
		
	
}
