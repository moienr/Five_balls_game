﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class whiteBallLoading : MonoBehaviour {

	bool gettingBigger = true;

	// Use this for initialization
	void Start () {
		StartCoroutine (loadBallRoutine());
	}
	
	IEnumerator loadBallRoutine () 
	{
		while(transform.localScale.x < 0.12f)
		{
			transform.localScale =Vector3.Lerp(transform.localScale , new Vector3(0.15f,0.15f,1) ,Time.deltaTime );
			yield return null;
		}
	}

	IEnumerator whiteBallBiggerLevelChange()
	{

			while(transform.localScale.x < 0.45f &&gettingBigger)
		{
			transform.localScale =Vector3.Lerp(transform.localScale , new Vector3(0.46f,0.46f,1) ,Time.deltaTime );
			yield return null;
		}
	
	}
		IEnumerator whiteBallSmallerLevelChange()
	{
		

		yield return new WaitForSeconds(3F);
		gettingBigger =false;

				while(transform.localScale.x > 0.12f)
		{
			transform.localScale =Vector3.Lerp(transform.localScale , new Vector3(0.115f,0.115f,1) ,Time.deltaTime );
			yield return null;
		}

		
	
	}




	// used in level2Background.cs 
	public void whiteBallBiggerLevelChangeCall()
	{
		
		
		
		StartCoroutine(whiteBallBiggerLevelChange());
	}
		public void whiteBallSmallerLevelChangeCall()
	{
		
		
		StartCoroutine(whiteBallSmallerLevelChange());
	}



}
