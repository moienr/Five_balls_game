﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class coca : MonoBehaviour {
	Rigidbody2D rigidbody;
	private void Start() {
		rigidbody = GetComponent<Rigidbody2D>();
	}
	private void OnCollisionEnter2D(Collision2D other) {
		rigidbody.gravityScale = 1;
	}
}
