﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class silingScript : MonoBehaviour {
	int level=1;	
	Rigidbody2D rb1;
    private bool didntHappenlvl1 =true;
	[SerializeField]
	private GameObject bigFlowerPotPrefab;
	[SerializeField]
	private GameObject level3Plane;
	GameManager gameManager;
    private bool didntHappenlvl3 =true;


    // Use this for initialization
    void Start () {
		gameManager = GameObject.Find("GameManager").GetComponent<GameManager>();
		level = gameManager.Level;

		//
		// adds force to the object that collided with it so it will fall faster , and also it will spwan objects like flower pot and palnes so it shows some easter-
		//-eggs about what the next level is gonna be.
		//
		
	}
	
	// Update is called once per frame

	private void OnTriggerEnter2D(Collider2D other) {
			rb1 =other.transform.GetComponent<Rigidbody2D>();
			rb1.velocity = Vector3.down *10;
			level = gameManager.Level;

			if (level==1 && didntHappenlvl1)
			{
				Instantiate (bigFlowerPotPrefab , new Vector3 (0.74f,11.98f,0) , Quaternion.Euler(0,0,42.6f)  );
				didntHappenlvl1 =false;
			}

			if (level==3 && didntHappenlvl3)
			{
				Instantiate (level3Plane , new Vector3(15.49f,13f ,0) ,Quaternion.Euler(0,0,23.628f));
				didntHappenlvl3 =false;
			}
			
			}
}
