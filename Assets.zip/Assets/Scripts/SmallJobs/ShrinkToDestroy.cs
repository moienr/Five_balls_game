﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShrinkToDestroy : MonoBehaviour {

	GameObject theNumber1;
	GameObject CocaCan;
	GameObject flowerPot;






	IEnumerator shrinkRoutine (GameObject toBeDestroyed) 
	{
		while(toBeDestroyed.transform.localScale.x > 0.001f)
		{
			toBeDestroyed.transform.localScale =Vector3.Lerp(toBeDestroyed.transform.localScale , new Vector3(0.0005f,0.0005f,1) ,Time.deltaTime *2 );
			yield return null;
		}
		Destroy(toBeDestroyed.gameObject);
	}

	public void ShrinkAndDestroy(GameObject toBeDestroyed) 
	{
		StartCoroutine(shrinkRoutine(toBeDestroyed));
	}



	public void level1To2() 
	{
		theNumber1 = GameObject.Find("1");
		CocaCan = GameObject .Find("coca cola");
		flowerPot = GameObject.Find("bigflowerPot(Clone)");

		if (theNumber1 != null)
		{
			ShrinkAndDestroy(theNumber1);
		}
			if (CocaCan != null)
		{
			ShrinkAndDestroy(CocaCan);
		}
			if (flowerPot != null)
		{
			ShrinkAndDestroy(flowerPot);
		}



	}
}
